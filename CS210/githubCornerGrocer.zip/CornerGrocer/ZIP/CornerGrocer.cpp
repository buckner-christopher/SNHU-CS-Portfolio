#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <limits>
using namespace std;

// Class to track grocery items and their frequencies
class GroceryTracker {
public:
    // Load items from file into map
    bool LoadFromFile(const string& path) {
        ifstream in(path);
        if (!in.is_open()) {
            cerr << "Error: Unable to open input file: " << path << endl;
            return false;
        }
        string item;
        while (getline(in, item)) {
            if (!item.empty()) {
                ++freq[item];
            }
        }
        return true;
    }

    // Write backup file
    bool WriteBackup(const string& path) const {
        ofstream out(path);
        if (!out.is_open()) {
            cerr << "Error: Unable to create backup file: " << path << endl;
            return false;
        }
        for (const auto& [item, count] : freq) {
            out << item << " " << count << "\n";
        }
        return true;
    }

    // Get frequency of a specific item
    int GetCount(const string& item) const {
        auto it = freq.find(item);
        return (it != freq.end()) ? it->second : 0;
    }

    // Print all items with counts
    void PrintAll() const {
        for (const auto& [item, count] : freq) {
            cout << item << " " << count << "\n";
        }
    }

    // Print histogram
    void PrintHistogram() const {
        for (const auto& [item, count] : freq) {
            cout << item << " ";
            for (int i = 0; i < count; ++i) {
                cout << "*";
            }
            cout << "\n";
        }
    }

private:
    map<string, int> freq;
};

// Print menu
static void PrintMenu() {
    cout << "\n==== Corner Grocer Menu ====\n"
        << "1. Search for item frequency\n"
        << "2. Print all item frequencies\n"
        << "3. Print histogram\n"
        << "4. Exit\n"
        << "Enter choice (1-4): ";
}

int main() {
    const string inputFile = "CS210_Project_Three_Input_File.txt";
    const string backupFile = "frequency.dat";

    GroceryTracker tracker;

    // Load data and write backup
    if (!tracker.LoadFromFile(inputFile)) {
        return 1; // exit if file not found
    }
    tracker.WriteBackup(backupFile);

    int choice;
    while (true) {
        PrintMenu();

        // Validate menu input
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number between 1 and 4.\n";
            continue;
        }

        if (choice < 1 || choice > 4) {
            cout << "Invalid choice. Please select 1�4.\n";
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear newline

        if (choice == 1) {
            cout << "Enter item name: ";
            string query;
            getline(cin, query);
            int count = tracker.GetCount(query);
            if (count == 0) {
                cout << "Item not found or purchased 0 times.\n";
            }
            else {
                cout << query << " " << count << "\n";
            }
        }
        else if (choice == 2) {
            tracker.PrintAll();
        }
        else if (choice == 3) {
            tracker.PrintHistogram();
        }
        else if (choice == 4) {
            cout << "Exiting. Goodbye!\n";
            break;
        }
    }

    return 0;
}